<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!--Google fonts-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Roboto:wght@300;500&display=swap"
          rel="stylesheet">

    <!--My css-->
    <link rel="stylesheet" href="app.css">

    <title>Document</title>
</head>
<body>
<?php

?>
<h1>Your data has been collected come back in 15 minutes.</h1>

<a href="show_logs.php">Show logs</a>

</body>
</html>