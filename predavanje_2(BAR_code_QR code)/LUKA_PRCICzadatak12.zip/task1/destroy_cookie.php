<?php

if (isset($_COOKIE['dataCollected'])) {
    unset($_COOKIE['dataCollected']);
}