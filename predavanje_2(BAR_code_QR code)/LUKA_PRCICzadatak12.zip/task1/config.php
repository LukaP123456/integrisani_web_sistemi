<?php
define('HOST','localhost');
define('USER','root');
define('PASSWORD','root');
define('DATABASE','iws');

date_default_timezone_set('Europe/Belgrade');