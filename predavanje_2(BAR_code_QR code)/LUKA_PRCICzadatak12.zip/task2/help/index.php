<!DOCTYPE html>
<html lang="en">
<head>
    <title>Task 2</title>
</head>
<body>
<!--<p>SCAN QR CODE!</p>-->
<?php
/*
require 'config.php';
require 'db.php';
*/
//require 'functions.php';
//$data = getQrCodeData();

require 'create_qr_code.php';

?>
</body>
</html>